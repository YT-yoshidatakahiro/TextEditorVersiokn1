﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VSC_Dentaku
{
    public partial class frm_Dentaku : Form
    {
        /// <summary>
        /// 初期表示設定
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frm_Dentaku_Load(object sender, EventArgs e)
        {
            this.StartPosition = FormStartPosition.Manual;

            this.Location = new Point(600, 150);
        }

        //グローバル変数
        public string keisankekka1;
        public string keisankekka2;

        public frm_Dentaku()
        {
            InitializeComponent();

            this.ControlBox = !this.ControlBox;

        }
        /// <summary>
        /// 閉じる
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_Close_Click(object sender, EventArgs e)
        {
            Close();
        }
        /// <summary>
        /// 0入力
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_zero_Click(object sender, EventArgs e)
        {
            keisankekka1 = keisankekka1+"0";

            txt_Result.Text = keisankekka1;
        }
        /// <summary>
        /// 1
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_one_Click(object sender, EventArgs e)
        {
            keisankekka1 = keisankekka1 + "1";

            txt_Result.Text = keisankekka1;
        }
        /// <summary>
        /// 2
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_two_Click(object sender, EventArgs e)
        {
            keisankekka1 = keisankekka1 + "2";

            txt_Result.Text = keisankekka1;
        }
        /// <summary>
        /// 3
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_three_Click(object sender, EventArgs e)
        {
            keisankekka1 = keisankekka1 + "3";

            txt_Result.Text = keisankekka1;
        }
        /// <summary>
        /// 4
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_four_Click(object sender, EventArgs e)
        {
            keisankekka1 = keisankekka1 + "4";

            txt_Result.Text = keisankekka1;
        }
        /// <summary>
        /// 5
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_five_Click(object sender, EventArgs e)
        {
            keisankekka1 = keisankekka1 + "5";

            txt_Result.Text = keisankekka1;
        }
        /// <summary>
        /// 6
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_six_Click(object sender, EventArgs e)
        {
            keisankekka1 = keisankekka1 + "6";

            txt_Result.Text = keisankekka1;
        }
        /// <summary>
        /// 7
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_seven_Click(object sender, EventArgs e)
        {
            keisankekka1 = keisankekka1 + "7";

            txt_Result.Text = keisankekka1;
        }
        /// <summary>
        /// 8
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_eight_Click(object sender, EventArgs e)
        {
            keisankekka1 = keisankekka1 + "8";

            txt_Result.Text = keisankekka1;
        }
        /// <summary>
        /// 9
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_nine_Click(object sender, EventArgs e)
        {
            keisankekka1 = keisankekka1 + "9";

            txt_Result.Text = keisankekka1;
        }
        /// <summary>
        /// リセット
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_allclear_Click(object sender, EventArgs e)
        {
            keisankekka1 = "";

            keisankekka2 = "";

            txt_Result.Text = keisankekka1;
        }
        /// <summary>
        /// 小数点
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_dot_Click(object sender, EventArgs e)
        {
            if (keisankekka1.Contains(".") == true)
            {

            }
            else
            {
                keisankekka1 = keisankekka1 + ".";
            }
        }
        /// <summary>
        /// 百分率
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_percent_Click(object sender, EventArgs e)
        {
            if (keisankekka1.Length > 0)
            {
                if (keisankekka1.Substring(0, 1) == "+")
                {
                    keisankekka1 = keisankekka1.Substring(0, 1) + (double.Parse(keisankekka1) / 100).ToString();
                }
                else
                {
                    keisankekka1 =  (double.Parse(keisankekka1) / 100).ToString();
                }
                txt_Result.Text = keisankekka1;
            }
        }
        /// <summary>
        /// 符号追加
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_plusminus_Click(object sender, EventArgs e)
        {
            if (!txt_Result.Text.Equals(""))
            {
                if (!keisankekka1.Substring(0, 1).Equals("+") && !keisankekka1.Substring(0, 1).Equals("-"))
                {
                    keisankekka1 = "+" + keisankekka1;

                    txt_Result.Text = keisankekka1;
                }
                else if (keisankekka1.Substring(0, 1).Equals("+"))
                {
                    keisankekka1 = "-" + keisankekka1.Substring(1);

                    txt_Result.Text = keisankekka1;

                }
                else if (keisankekka1.Substring(0, 1).Equals("-"))
                {
                    keisankekka1 = "+" + keisankekka1.Substring(1);

                    txt_Result.Text = keisankekka1;

                }
            }
        }
        /// <summary>
        /// ÷
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_dev_Click(object sender, EventArgs e)
        {

            Method_Calc("/");

        }
        /// <summary>
        /// ×
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_product_Click(object sender, EventArgs e)
        {
            Method_Calc("*");
        }
        /// <summary>
        /// +
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_plus_Click(object sender, EventArgs e)
        {
            Method_Calc("+");
        }
        /// <summary>
        /// -
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_minus_Click(object sender, EventArgs e)
        {
            Method_Calc("-");
        }
        /// <summary>
        /// =
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_equal_Click(object sender, EventArgs e)
        {
            Method_Calc("=");
        }
        /// <summary>
        /// 四則演算メソッド
        /// </summary>
        /// <param name="Data"></param>
        private void Method_Calc(String Data)
        {
            keisankekka2 += keisankekka1 + Data;

            DataTable dt = new DataTable();

            object dat = 0;

            for (int i = 0; i < keisankekka2.Length - 1; i++)
            {
                if (keisankekka2.Substring(i, 1) == "/" || keisankekka2.Substring(i, 1) == "*" ||
                    keisankekka2.Substring(i, 1) == "+" || keisankekka2.Substring(i, 1) == "-")
                {
                    if (i == 0 || i == keisankekka2.Length - 1)
                    {
                        txt_Result.Text = keisankekka1;
                    }
                    else
                    {
                        if (keisankekka2.Substring(keisankekka2.Length - 2, 2) == Data+"/" || keisankekka2.Substring(keisankekka2.Length - 2, 2) == Data + "*" ||
                            keisankekka2.Substring(keisankekka2.Length - 2, 2) == Data + "+"|| keisankekka2.Substring(keisankekka2.Length - 2, 2) == Data + "-")
                        {
                            keisankekka2 = keisankekka2.Substring(0, keisankekka2.Length - 1);
                        }
                        try
                        {
                            dat = dt.Compute(keisankekka2.Substring(0, keisankekka2.Length - 1), "");

                            keisankekka2 = dat.ToString();

                            txt_Result.Text = keisankekka2;

                            if (Data == "=")
                            {
                                keisankekka2 = dat.ToString() + Data;
                            }
                            else
                            {
                                keisankekka2 = dat.ToString() + Data;
                            }
                        }
                        catch (Exception e){
                            
                            keisankekka1 = "";

                            keisankekka2 = "";

                            txt_Result.Text = "";
                        }
                        break;
                    }
                }
            }

            keisankekka1 = "";
        }

    }
}
