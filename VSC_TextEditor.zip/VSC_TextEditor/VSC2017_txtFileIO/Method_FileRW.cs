﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Method_FileRW
{
    public Method_FileRW()
    {
    }

    //読込形式一覧
    public static string filename0 =
        ("*.txt") + "|" + ("*.txt") +
        "|" + ("*.csv") + "|" + ("*.csv") +
        "|" + ("*.pas") + "|" + ("*.pas") +
        "|" + ("*.java") + "|" + ("*.java") +
        "|" + ("*.cs") + "|" + ("*.cs");
    public static string filename = filename0;
    /// 
    /// ファイル開くメソッド
    /// </summary>
    public void Method_OpenFile(OpenFileDialog open_file,
        Control pathbefore, Control pathafter, Control richbefore, Control richafter, DataGridView gridbefore, DataGridView gridafter)
    {
        open_file.Filter = filename;
        open_file.FileName = "";

        open_file.RestoreDirectory = true;

        if (open_file.ShowDialog() == DialogResult.OK)
        {
            pathafter.Text = open_file.FileName;

            pathbefore.Text = open_file.FileName;

            if (open_file.FileName.EndsWith(".csv"))
            {
                Method_BeforeReadCSV(open_file.FileName, gridafter);

                Method_BeforeReadCSV(open_file.FileName, gridbefore);

            }
            else
            {
                Method_BeforeRead(open_file.FileName, richbefore, richafter);
            }
        }
    }
    /// <summary>
    /// txt保存ダイアログ開くメソッド
    /// </summary>
    public void Method_OpenSaveDialog(SaveFileDialog save_file,
        Control pathbefore, Control pathafter, Control richbefore, Control richafter)
    {
        DialogResult result = MessageBox.Show("編集を保存する？", "保存確認", MessageBoxButtons.YesNo);

        if (result == DialogResult.Yes)
        {
            save_file.Filter = ("*.txt") + "|" + ("*.txt");

            save_file.RestoreDirectory = true;

            save_file.ShowDialog();

            pathbefore.Text = save_file.FileName;

            pathafter.Text = save_file.FileName;

            StreamWriter after_write = new StreamWriter(save_file.FileName);

            after_write.Write(pathafter.Text);

            after_write.Close();
        }
    }
    /// <summary>
    /// CSV保存ダイアログ開くメソッド
    /// </summary>
    public void Method_OpenSaveDialogCSV(SaveFileDialog save_file,
        Control pathbefore, Control pathafter, DataGridView gridbefore, DataGridView gridafter)
    {
        DialogResult result = MessageBox.Show("編集を保存する？", "保存確認", MessageBoxButtons.YesNo);

        string filename = "";

        if (result == DialogResult.Yes)
        {
            save_file.Filter = ("*.csv") + "|" + ("*.csv");

            save_file.RestoreDirectory = true;

            save_file.ShowDialog();

            StreamWriter after_write = new StreamWriter(save_file.FileName);

            filename = save_file.FileName;

            pathbefore.Text = save_file.FileName;

            pathafter.Text = save_file.FileName;

            string tmpdat = "";

            int i;

            int j;

            for (i = 0; i < gridafter.ColumnCount; i++)
            {
                if (i < gridafter.ColumnCount - 1)
                {
                    tmpdat += gridafter.Columns[i].HeaderText + ",";
                }
                if (i == gridafter.ColumnCount - 1)
                {
                    tmpdat += gridafter.Columns[i].HeaderText + "," + "\r\n";

                }
            }

            for (j = 0; j < gridafter.RowCount - 1; j++)
            {
                for (i = 0; i < gridafter.ColumnCount; i++)
                {
                    tmpdat += gridafter.Rows[j].Cells[i].Value + ",";
                }
                if (j < gridafter.RowCount - 2)
                {
                    tmpdat += "\r\n";
                }
                if (j == gridafter.RowCount - 2)
                {
                    tmpdat = tmpdat.Substring(0, tmpdat.Length - 1);
                }
            }
            after_write.Write(tmpdat);

            after_write.Close();
        }
    }
    /// <summary>
    /// テキストファイル読込メソッド
    /// </summary>
    /// <param name="Dat"></param>
    public void Method_BeforeRead(string opendialogname, Control richbefore, Control richafter)
    {
        string tmpstr = "";

        string result = "";

        StreamReader before_read = new StreamReader(opendialogname);

        tmpstr = before_read.ReadToEnd();

        before_read.Close();

        result += tmpstr;

        richbefore.Text = result;

        richafter.Text = richbefore.Text;
    }
    /// <summary>
    /// CSVファイル読込メソッド
    /// </summary>
    public void Method_BeforeReadCSV(string opendialogname, DataGridView Obj)
    {
        Obj.Rows.Clear();

        Obj.Columns.Clear();

        StreamReader before_read = new StreamReader(opendialogname);

        string tmpstr = "";

        List<string> datrow = new List<string>();
        tmpstr = before_read.ReadToEnd();

        int j;

        int rncount = 0;

        string cutword = "";

        string result = "";

        int flagcol = 1;


        for (j = 0; j < tmpstr.Length; j++)
        {
            cutword = tmpstr.Substring(j, 1).ToString();

            if (j == 0 && cutword == "\r")
            {

            }
            else
            {
                if (cutword != "\r" && cutword != "\n")
                {
                    result += cutword;

                    if (result.EndsWith(",,"))
                    {
                        datrow.Add(result.Substring(0, result.Length - 2));

                        //列名作成と行数取得
                        if (flagcol == 1)
                        {
                            Obj.Columns.Add(result, result);
                        }

                        datrow.Add(" ");

                        result = "";
                    }
                    else if (result.EndsWith("," + cutword))
                    {
                        datrow.Add(result.Substring(0, result.Length - 2));

                        result = result.Substring(result.Length - 1);

                        //列名作成と行数取得
                        if (flagcol == 1)
                        {
                            Obj.Columns.Add(result, result);
                        }
                    }
                }
                //見出し行列の終了
                if (cutword == "\r" || j == tmpstr.Length - 1)
                {
                    if (result.EndsWith(",") && cutword == "\r")
                    {
                        result = result.Substring(0, result.Length - 1);

                        datrow.Add(result);
                        //列名作成と行数取得
                        if (flagcol == 1)
                        {
                            Obj.Columns.Add(result, result);

                            flagcol = 0;
                        }

                        result = "";
                    }

                    rncount += 1;

                    //行挿入
                    if (flagcol == 0)
                    {
                        if (rncount >= 1)
                        {
                            Obj.Rows.Add(datrow.ToArray());

                            datrow.Clear();
                        }
                    }
                }
            }
        }
        Obj.Rows.RemoveAt(0);

        before_read.Close();

        datrow.Clear();
    }
}