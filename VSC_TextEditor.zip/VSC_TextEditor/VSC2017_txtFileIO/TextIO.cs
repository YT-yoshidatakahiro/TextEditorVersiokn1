﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.IO;
using System.Windows.Controls;
using System.Runtime.InteropServices; // DLL Import
                                      //WindowsBase.dll
                                      //PresentationCore.dll
                                      //PresentationFramework.dll
namespace VSC2017_txtFileIO
{

    public partial class frm_txtIO : Form
    {

        frm_FindReplace findrep;

        public frm_txtIO()
        {
            InitializeComponent();

            rich_After.AllowDrop = true;

            csv_After.AllowDrop = true;
        }
        //初期設定の画面サイズ
        int sw = 900;
        int sh = 200;
        /// <summary>
                 /// 初期表示設定
                 /// </summary>
                 /// <param name="sender"></param>
                 /// <param name="e"></param>
        private void frm_txtIO_Load(object sender, EventArgs e)
        {
            
            this.StartPosition = FormStartPosition.Manual;

            this.Location = new Point(0, 80);

            this.Size = new Size(sw, sh);

            this.ControlBox = false;

            this.rich_Before.VScroll += new System.EventHandler(this.rich_Before_VScroll);

            this.rich_After.VScroll += new System.EventHandler(this.rich_After_VScroll);

            this.rich_Before.HScroll += new System.EventHandler(this.rich_Before_HScroll);

            this.rich_After.HScroll += new System.EventHandler(this.rich_After_HScroll);

            this.csv_Before.Scroll += new ScrollEventHandler(csv_Before_Scroll);

            this.csv_After.Scroll += new ScrollEventHandler(csv_After_Scroll);

            this.csv_After.DragDrop += new System.Windows.Forms.DragEventHandler(this.rich_After_DragDrop);

            this.csv_After.DragEnter += new System.Windows.Forms.DragEventHandler(this.rich_After_DragEnter);

            this.rich_After.DragDrop += new System.Windows.Forms.DragEventHandler(this.rich_After_DragDrop);

            this.rich_After.DragEnter += new System.Windows.Forms.DragEventHandler(this.rich_After_DragEnter);

            this.csv_After.DoubleClick += new System.EventHandler(this.csv_After_DoubleClick);
        }

        /// <summary>
        /// 左右上下同時スクロール
        /// </summary>
        const int WM_USER = 0x400;

        const int EM_GETSCROLLPOS = WM_USER + 221;

        const int EM_SETSCROLLPOS = WM_USER + 222;

        [System.Runtime.InteropServices.DllImport("user32.dll")]

        static extern int SendMessage(IntPtr hWnd, int msg, int wParam, ref Point lParam);
        /// <summary>
        /// テキストボックス同時
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void rich_Before_VScroll(object sender, EventArgs e)
        {
            Point pt = new Point();

            SendMessage(rich_Before.Handle, EM_GETSCROLLPOS, 0, ref pt);

            SendMessage(rich_After.Handle, EM_SETSCROLLPOS, 0, ref pt);

        }
        private void rich_After_VScroll(object sender, EventArgs e)
        {
            Point pt = new Point(); 

            SendMessage(rich_Before.Handle, EM_GETSCROLLPOS, 0, ref pt);

            SendMessage(rich_After.Handle, EM_SETSCROLLPOS, 0, ref pt);
        }
        private void rich_Before_HScroll(object sender, EventArgs e)
        {
            Point pt = new Point();

            SendMessage(rich_Before.Handle, EM_GETSCROLLPOS, 0, ref pt);

            SendMessage(rich_After.Handle, EM_SETSCROLLPOS, 0, ref pt);
        }
        private void rich_After_HScroll(object sender, EventArgs e)
        {
            Point pt = new Point();

            SendMessage(rich_Before.Handle, EM_GETSCROLLPOS, 0, ref pt);

            SendMessage(rich_After.Handle, EM_SETSCROLLPOS, 0, ref pt);
        }
        /// <summary>
        /// CSV同時
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void csv_Before_Scroll(object sender, ScrollEventArgs e)
        {
            this.csv_After.FirstDisplayedScrollingRowIndex = this.csv_Before.FirstDisplayedScrollingRowIndex;

            this.csv_After.FirstDisplayedScrollingColumnIndex = this.csv_Before.FirstDisplayedScrollingColumnIndex;
        }
        private void csv_After_Scroll(object sender, ScrollEventArgs e)
        {
            this.csv_Before.FirstDisplayedScrollingRowIndex = this.csv_After.FirstDisplayedScrollingRowIndex;

            this.csv_Before.FirstDisplayedScrollingColumnIndex = this.csv_After.FirstDisplayedScrollingColumnIndex;
        }
        /// <summary>
        /// 画面拡大縮小
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_Max_Click(object sender, EventArgs e)
        {
            //ワーキングエリアの横×高さ
            int ww = SystemInformation.WorkingArea.Width;
            int wh = SystemInformation.WorkingArea.Height;

            if (this.Size.Width == ww || this.Size.Height == wh)
            {
                this.Size = new Size(sw, sh);

                this.Location = new Point(0, 80);
            }
            else
            {
                this.Size = new Size(ww, wh);

                this.Location = new Point(0, 0);
            }
        }
        /// <summary>
        /// 機能情報ボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_Help_Click(object sender, EventArgs e)
        {
            string info1 = "テキスト編集ソフト Ver 2.0\n" +
                "・1行100列の挿入（CSV未読込時のダブルクリック）\n" +
                "・編集前後の左右上下同時スクロール\n" +
                "・検索と置換（ctrl + f/h）\n" +
                "・保存（ctrl + s）\n" +
                "・ファイルオープン（ctrl + o）\n" +
                "・ファイルドロップ機能\n" +
                "・検索と置換（ctrl + f/h）\n"+
                "・フォーム終了（ctrl + w）\n";
            MessageBox.Show(info1, "機能情報");
        }
        /// <summary>
        /// 閉じる
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_Close_Click(object sender, EventArgs e)
        {
            Method_FileRW method_filewr = new Method_FileRW();

            if ((rich_After.Text.Length != rich_Before.Text.Length))
            {
                method_filewr.Method_OpenSaveDialog(save_File, txt_BeforePath, txt_AfterPath, rich_Before, rich_After);
            }
            if ( (csv_After.Rows.Count != csv_Before.Rows.Count))
            {
                method_filewr.Method_OpenSaveDialogCSV(save_File, txt_BeforePath, txt_AfterPath, csv_Before, csv_After);
            }
            Close();
        }
        /// <summary>
        /// 保存ボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_Save_Click(object sender, EventArgs e)
        {
            Method_FileRW method_filewr = new Method_FileRW();

            if (tab_After.SelectedTab.Name.Contains("txt"))
            {
                method_filewr.Method_OpenSaveDialog(save_File,txt_BeforePath, txt_AfterPath, rich_Before, rich_After);

                rich_Before.Text = rich_After.Text;
            }
            if (tab_After.SelectedTab.Name.Contains("csv"))
            {
                method_filewr.Method_OpenSaveDialogCSV(save_File, txt_BeforePath, txt_AfterPath, csv_Before, csv_After);

                csv_Before.Rows.Clear();

                csv_Before.Columns.Clear();

                method_filewr.Method_BeforeReadCSV(txt_BeforePath.Text, csv_Before);
            }
        }
        /// <summary>
        /// ファイル読込
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_Read_Click(object sender, EventArgs e)
        {
            Method_FileRW method_filewr = new Method_FileRW();

            method_filewr.Method_OpenFile(open_File,txt_BeforePath,txt_AfterPath,rich_Before,rich_After,csv_Before,csv_After);

            if (txt_BeforePath.Text.Contains(".csv"))
            {
                tab_Before.SelectTab("before_csv");
                tab_After.SelectTab("after_csv");
            }
            else
            {
                tab_Before.SelectTab("before_txt");
                tab_After.SelectTab("after_txt");
            }

        }
        /// <summary>
        /// グリッドビューが白紙なら，ダブルクリックで1行100列追加
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void csv_After_DoubleClick(object sender, EventArgs e)
        {

            int i = 0;

            if (csv_After.Columns.Count<=0)
            {
                MessageBox.Show("デフォルトとして，100列追加します");

                for (i = 0; i < 100; i++)
                {
                    csv_After.Columns.Add(i.ToString(), "");
                }
            }
            else
            {
            }
        }
        /// <summary>
        /// インデント設定：Delphi形式
        /// インデントは半角空白2文字分
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_Indent_Click(object sender, EventArgs e)
        {

            string tmprstr = "";
            Method_Indent method_indent = new Method_Indent();


            if (txt_BeforePath.Text.EndsWith(".txt"))
            {
                //左詰め
                tmprstr = method_indent.Method_Left(rich_Before.Text, txt_BeforePath.Text);

                //beginend関連インデント
                tmprstr = method_indent.Method_BeginEnd(tmprstr);

                //最終出力
                rich_After.Text = "";

                rich_After.Text = tmprstr;
            }
        }
        /// <summary>
        /// タブ選択時のファイル開く
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tab_Before_Click(object sender, EventArgs e)
        {
            Method_FileRW test = new Method_FileRW();

            if (tab_Before.SelectedTab==before_csv)
            {
                tab_After.SelectTab(after_csv);
                Method_FileRW.filename = "";
                Method_FileRW.filename = ("*.csv") + "|" + ("*.csv") + "|" + Method_FileRW.filename0;

            }
            else if (tab_Before.SelectedTab == before_txt)
            {
                tab_After.SelectTab(after_txt);
                Method_FileRW.filename = "";
                Method_FileRW.filename = ("*.txt") + "|" + ("*.txt") + "|" + Method_FileRW.filename0;
            }
        }
        /// <summary>
        /// タブ選択時のファイル開く
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tab_After_Click(object sender, EventArgs e)
        {
            Method_FileRW test = new Method_FileRW();

            if (tab_After.SelectedTab == after_csv)
            {
                tab_Before.SelectTab(before_csv);

                Method_FileRW.filename = "";
                Method_FileRW.filename = ("*.csv") + "|" + ("*.csv")+ "|" + Method_FileRW.filename0;
            }
            else if (tab_After.SelectedTab == after_txt)
            {
                tab_Before.SelectTab(before_txt);

                Method_FileRW.filename = "";
                Method_FileRW.filename = ("*.txt") + "|" + ("*.txt") + "|" + Method_FileRW.filename0;
            }
        }
        /// <summary>
        /// ファイルの取り込み（txtdoc(x)，csv(xls(x))）
        /// ドラッグドロップ操作
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void rich_After_DragEnter(object sender, System.Windows.Forms.DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effect = DragDropEffects.Copy;
            }
            else
            {
                e.Effect = DragDropEffects.None;
            }
        }
        private void rich_After_DragDrop(object sender, System.Windows.Forms.DragEventArgs e)
        {

            Method_FileRW method_filewr = new Method_FileRW();

            try
            {
                Array a = (Array)e.Data.GetData(DataFormats.FileDrop);
                if (a != null)
                {
                    string s = a.GetValue(0).ToString();
                    this.Activate();

                    txt_BeforePath.Text = s;

                    txt_AfterPath.Text = s;

                    if (s.EndsWith(".txt"))
                    {
                        method_filewr.Method_BeforeRead(s, rich_Before, rich_After);
                    }
                    else if (s.EndsWith(".csv"))
                    {
                        tab_Before.SelectTab(before_csv);

                        tab_After.SelectTab(after_csv);

                        method_filewr.Method_BeforeReadCSV(open_File.FileName, csv_Before);

                        method_filewr.Method_BeforeReadCSV(open_File.FileName, csv_After);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in DragDrop function: " + ex.Message);
            }
        }
        /// <summary>
        /// キー操作
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="keyData"></param>
        /// <returns></returns>
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            Method_FileRW method_filewr = new Method_FileRW();

            //Ctrl + Sキー 保存
            if (keyData == (Keys.Control | Keys.S))
            {
                if (tab_After.SelectedTab.Name.Contains("txt"))
                {
                    txt_BeforePath.Text = txt_AfterPath.Text;

                    method_filewr.Method_OpenSaveDialog(save_File, txt_BeforePath, txt_AfterPath, rich_Before, rich_After);

                    rich_Before.Text = rich_After.Text;
                }
                else if (tab_After.SelectedTab.Name.Contains("csv"))
                {
                    method_filewr.Method_OpenSaveDialogCSV(save_File, txt_BeforePath, txt_AfterPath, csv_Before, csv_After);

                    txt_BeforePath.Text = txt_AfterPath.Text;

                    csv_Before.Rows.Clear();

                    csv_Before.Columns.Clear();

                    method_filewr.Method_BeforeReadCSV(txt_BeforePath.Text, csv_Before);
                }

                return true;
            }
            //検索
            if (keyData == (Keys.Control | (Keys.F)))
            {
                findrep = new frm_FindReplace(rich_After);

                findrep.Show();

                return true;
            }
            //ファイル開く
            if (keyData == (Keys.Control | (Keys.O)))
            {
                method_filewr.Method_OpenFile(open_File, txt_BeforePath, txt_AfterPath, rich_Before, rich_After, csv_Before, csv_After);

                return true;
            }
            //フォームアプリを閉じる
            if (keyData == (Keys.Control | (Keys.W)))
            {
                Close();

                return true;
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }


    }
}
