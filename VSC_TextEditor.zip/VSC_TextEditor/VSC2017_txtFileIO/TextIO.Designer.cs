﻿namespace VSC2017_txtFileIO
{
    partial class frm_txtIO
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージド リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Read = new System.Windows.Forms.Button();
            this.bbtnSave = new System.Windows.Forms.Button();
            this.open_File = new System.Windows.Forms.OpenFileDialog();
            this.save_File = new System.Windows.Forms.SaveFileDialog();
            this.tab_Before = new System.Windows.Forms.TabControl();
            this.before_txt = new System.Windows.Forms.TabPage();
            this.rich_Before = new System.Windows.Forms.RichTextBox();
            this.before_csv = new System.Windows.Forms.TabPage();
            this.csv_Before = new System.Windows.Forms.DataGridView();
            this.btn_Close = new System.Windows.Forms.Button();
            this.label_Before = new System.Windows.Forms.Label();
            this.label_After = new System.Windows.Forms.Label();
            this.tab_After = new System.Windows.Forms.TabControl();
            this.after_txt = new System.Windows.Forms.TabPage();
            this.rich_After = new System.Windows.Forms.RichTextBox();
            this.after_csv = new System.Windows.Forms.TabPage();
            this.csv_After = new System.Windows.Forms.DataGridView();
            this.txt_BeforePath = new System.Windows.Forms.TextBox();
            this.txt_AfterPath = new System.Windows.Forms.TextBox();
            this.btn_Indent = new System.Windows.Forms.Button();
            this.btn_Help = new System.Windows.Forms.Button();
            this.cmb_Language = new System.Windows.Forms.ComboBox();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.colorDialog2 = new System.Windows.Forms.ColorDialog();
            this.colorDialog3 = new System.Windows.Forms.ColorDialog();
            this.btn_Max = new System.Windows.Forms.Button();
            this.tab_Before.SuspendLayout();
            this.before_txt.SuspendLayout();
            this.before_csv.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.csv_Before)).BeginInit();
            this.tab_After.SuspendLayout();
            this.after_txt.SuspendLayout();
            this.after_csv.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.csv_After)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Read
            // 
            this.btn_Read.Font = new System.Drawing.Font("ＭＳ ゴシック", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btn_Read.Location = new System.Drawing.Point(12, 12);
            this.btn_Read.Name = "btn_Read";
            this.btn_Read.Size = new System.Drawing.Size(81, 49);
            this.btn_Read.TabIndex = 1;
            this.btn_Read.Text = "読込";
            this.btn_Read.UseVisualStyleBackColor = true;
            this.btn_Read.Click += new System.EventHandler(this.btn_Read_Click);
            // 
            // bbtnSave
            // 
            this.bbtnSave.Font = new System.Drawing.Font("ＭＳ ゴシック", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.bbtnSave.Location = new System.Drawing.Point(99, 12);
            this.bbtnSave.Name = "bbtnSave";
            this.bbtnSave.Size = new System.Drawing.Size(88, 49);
            this.bbtnSave.TabIndex = 1;
            this.bbtnSave.Text = "保存";
            this.bbtnSave.UseVisualStyleBackColor = true;
            this.bbtnSave.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // open_File
            // 
            this.open_File.FileName = "openFileDialog1";
            // 
            // tab_Before
            // 
            this.tab_Before.AllowDrop = true;
            this.tab_Before.Controls.Add(this.before_txt);
            this.tab_Before.Controls.Add(this.before_csv);
            this.tab_Before.Location = new System.Drawing.Point(23, 132);
            this.tab_Before.Multiline = true;
            this.tab_Before.Name = "tab_Before";
            this.tab_Before.SelectedIndex = 0;
            this.tab_Before.Size = new System.Drawing.Size(900, 850);
            this.tab_Before.TabIndex = 3;
            this.tab_Before.Click += new System.EventHandler(this.tab_Before_Click);
            // 
            // before_txt
            // 
            this.before_txt.Controls.Add(this.rich_Before);
            this.before_txt.Location = new System.Drawing.Point(4, 22);
            this.before_txt.Name = "before_txt";
            this.before_txt.Padding = new System.Windows.Forms.Padding(3);
            this.before_txt.Size = new System.Drawing.Size(892, 824);
            this.before_txt.TabIndex = 0;
            this.before_txt.Text = "テキスト";
            this.before_txt.UseVisualStyleBackColor = true;
            // 
            // rich_Before
            // 
            this.rich_Before.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rich_Before.Font = new System.Drawing.Font("ＭＳ ゴシック", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.rich_Before.Location = new System.Drawing.Point(6, 6);
            this.rich_Before.Name = "rich_Before";
            this.rich_Before.ReadOnly = true;
            this.rich_Before.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth;
            this.rich_Before.Size = new System.Drawing.Size(880, 799);
            this.rich_Before.TabIndex = 0;
            this.rich_Before.Text = "";
            this.rich_Before.WordWrap = false;
            // 
            // before_csv
            // 
            this.before_csv.Controls.Add(this.csv_Before);
            this.before_csv.Location = new System.Drawing.Point(4, 22);
            this.before_csv.Name = "before_csv";
            this.before_csv.Padding = new System.Windows.Forms.Padding(3);
            this.before_csv.Size = new System.Drawing.Size(892, 824);
            this.before_csv.TabIndex = 1;
            this.before_csv.Text = "CSV";
            this.before_csv.UseVisualStyleBackColor = true;
            // 
            // csv_Before
            // 
            this.csv_Before.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.csv_Before.Location = new System.Drawing.Point(6, 6);
            this.csv_Before.Name = "csv_Before";
            this.csv_Before.ReadOnly = true;
            this.csv_Before.RowTemplate.Height = 21;
            this.csv_Before.Size = new System.Drawing.Size(880, 799);
            this.csv_Before.TabIndex = 0;
            // 
            // btn_Close
            // 
            this.btn_Close.Font = new System.Drawing.Font("ＭＳ ゴシック", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btn_Close.Location = new System.Drawing.Point(194, 12);
            this.btn_Close.Name = "btn_Close";
            this.btn_Close.Size = new System.Drawing.Size(88, 49);
            this.btn_Close.TabIndex = 1;
            this.btn_Close.Text = "閉じる";
            this.btn_Close.UseVisualStyleBackColor = true;
            this.btn_Close.Click += new System.EventHandler(this.btn_Close_Click);
            // 
            // label_Before
            // 
            this.label_Before.AutoSize = true;
            this.label_Before.Font = new System.Drawing.Font("ＭＳ ゴシック", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label_Before.Location = new System.Drawing.Point(850, 83);
            this.label_Before.Name = "label_Before";
            this.label_Before.Size = new System.Drawing.Size(69, 19);
            this.label_Before.TabIndex = 4;
            this.label_Before.Text = "編集前";
            // 
            // label_After
            // 
            this.label_After.AutoSize = true;
            this.label_After.Font = new System.Drawing.Font("ＭＳ ゴシック", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label_After.Location = new System.Drawing.Point(945, 83);
            this.label_After.Name = "label_After";
            this.label_After.Size = new System.Drawing.Size(69, 19);
            this.label_After.TabIndex = 4;
            this.label_After.Text = "編集後";
            // 
            // tab_After
            // 
            this.tab_After.Controls.Add(this.after_txt);
            this.tab_After.Controls.Add(this.after_csv);
            this.tab_After.Location = new System.Drawing.Point(945, 132);
            this.tab_After.Name = "tab_After";
            this.tab_After.SelectedIndex = 0;
            this.tab_After.Size = new System.Drawing.Size(900, 850);
            this.tab_After.TabIndex = 3;
            this.tab_After.Click += new System.EventHandler(this.tab_After_Click);
            // 
            // after_txt
            // 
            this.after_txt.Controls.Add(this.rich_After);
            this.after_txt.Location = new System.Drawing.Point(4, 22);
            this.after_txt.Name = "after_txt";
            this.after_txt.Padding = new System.Windows.Forms.Padding(3);
            this.after_txt.Size = new System.Drawing.Size(892, 824);
            this.after_txt.TabIndex = 0;
            this.after_txt.Text = "テキスト";
            this.after_txt.UseVisualStyleBackColor = true;
            // 
            // rich_After
            // 
            this.rich_After.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rich_After.Font = new System.Drawing.Font("ＭＳ ゴシック", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.rich_After.Location = new System.Drawing.Point(6, 6);
            this.rich_After.Name = "rich_After";
            this.rich_After.Size = new System.Drawing.Size(880, 799);
            this.rich_After.TabIndex = 0;
            this.rich_After.Text = "";
            this.rich_After.WordWrap = false;
            // 
            // after_csv
            // 
            this.after_csv.Controls.Add(this.csv_After);
            this.after_csv.Location = new System.Drawing.Point(4, 22);
            this.after_csv.Name = "after_csv";
            this.after_csv.Padding = new System.Windows.Forms.Padding(3);
            this.after_csv.Size = new System.Drawing.Size(892, 824);
            this.after_csv.TabIndex = 1;
            this.after_csv.Text = "CSV";
            this.after_csv.UseVisualStyleBackColor = true;
            // 
            // csv_After
            // 
            this.csv_After.AllowDrop = true;
            this.csv_After.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.csv_After.Location = new System.Drawing.Point(6, 6);
            this.csv_After.Name = "csv_After";
            this.csv_After.RowTemplate.Height = 21;
            this.csv_After.ShowCellToolTips = false;
            this.csv_After.Size = new System.Drawing.Size(880, 799);
            this.csv_After.TabIndex = 0;
            // 
            // txt_BeforePath
            // 
            this.txt_BeforePath.Font = new System.Drawing.Font("ＭＳ ゴシック", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txt_BeforePath.Location = new System.Drawing.Point(23, 107);
            this.txt_BeforePath.Multiline = true;
            this.txt_BeforePath.Name = "txt_BeforePath";
            this.txt_BeforePath.ReadOnly = true;
            this.txt_BeforePath.Size = new System.Drawing.Size(890, 19);
            this.txt_BeforePath.TabIndex = 5;
            // 
            // txt_AfterPath
            // 
            this.txt_AfterPath.Font = new System.Drawing.Font("ＭＳ ゴシック", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txt_AfterPath.Location = new System.Drawing.Point(945, 107);
            this.txt_AfterPath.Multiline = true;
            this.txt_AfterPath.Name = "txt_AfterPath";
            this.txt_AfterPath.ReadOnly = true;
            this.txt_AfterPath.Size = new System.Drawing.Size(890, 19);
            this.txt_AfterPath.TabIndex = 5;
            // 
            // btn_Indent
            // 
            this.btn_Indent.Font = new System.Drawing.Font("ＭＳ ゴシック", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btn_Indent.Location = new System.Drawing.Point(1364, 32);
            this.btn_Indent.Name = "btn_Indent";
            this.btn_Indent.Size = new System.Drawing.Size(166, 29);
            this.btn_Indent.TabIndex = 6;
            this.btn_Indent.Text = "インデント整形";
            this.btn_Indent.UseVisualStyleBackColor = true;
            this.btn_Indent.Visible = false;
            this.btn_Indent.Click += new System.EventHandler(this.btn_Indent_Click);
            // 
            // btn_Help
            // 
            this.btn_Help.Font = new System.Drawing.Font("ＭＳ ゴシック", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btn_Help.Location = new System.Drawing.Point(288, 12);
            this.btn_Help.Name = "btn_Help";
            this.btn_Help.Size = new System.Drawing.Size(109, 49);
            this.btn_Help.TabIndex = 7;
            this.btn_Help.Text = "機能情報";
            this.btn_Help.UseVisualStyleBackColor = true;
            this.btn_Help.Click += new System.EventHandler(this.btn_Help_Click);
            // 
            // cmb_Language
            // 
            this.cmb_Language.FormattingEnabled = true;
            this.cmb_Language.Items.AddRange(new object[] {
            "インデント整形種類",
            "*.pas"});
            this.cmb_Language.Location = new System.Drawing.Point(1364, 6);
            this.cmb_Language.Name = "cmb_Language";
            this.cmb_Language.Size = new System.Drawing.Size(166, 20);
            this.cmb_Language.TabIndex = 8;
            this.cmb_Language.Text = "インデント整形種類";
            this.cmb_Language.Visible = false;
            // 
            // btn_Max
            // 
            this.btn_Max.Font = new System.Drawing.Font("ＭＳ ゴシック", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btn_Max.Location = new System.Drawing.Point(403, 12);
            this.btn_Max.Name = "btn_Max";
            this.btn_Max.Size = new System.Drawing.Size(128, 49);
            this.btn_Max.TabIndex = 9;
            this.btn_Max.Text = "画面\r\nサイズ変更";
            this.btn_Max.UseVisualStyleBackColor = true;
            this.btn_Max.Click += new System.EventHandler(this.btn_Max_Click);
            // 
            // frm_txtIO
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1924, 861);
            this.Controls.Add(this.btn_Max);
            this.Controls.Add(this.cmb_Language);
            this.Controls.Add(this.btn_Help);
            this.Controls.Add(this.btn_Indent);
            this.Controls.Add(this.txt_AfterPath);
            this.Controls.Add(this.txt_BeforePath);
            this.Controls.Add(this.label_After);
            this.Controls.Add(this.label_Before);
            this.Controls.Add(this.tab_After);
            this.Controls.Add(this.tab_Before);
            this.Controls.Add(this.btn_Close);
            this.Controls.Add(this.bbtnSave);
            this.Controls.Add(this.btn_Read);
            this.Name = "frm_txtIO";
            this.Text = "ファイル編集画面";
            this.Load += new System.EventHandler(this.frm_txtIO_Load);
            this.tab_Before.ResumeLayout(false);
            this.before_txt.ResumeLayout(false);
            this.before_csv.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.csv_Before)).EndInit();
            this.tab_After.ResumeLayout(false);
            this.after_txt.ResumeLayout(false);
            this.after_csv.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.csv_After)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Read;
        private System.Windows.Forms.Button bbtnSave;
        private System.Windows.Forms.OpenFileDialog open_File;
        private System.Windows.Forms.SaveFileDialog save_File;
        private System.Windows.Forms.TabControl tab_Before;
        private System.Windows.Forms.TabPage before_txt;
        private System.Windows.Forms.TabPage before_csv;
        private System.Windows.Forms.Button btn_Close;
        private System.Windows.Forms.RichTextBox rich_Before;
        private System.Windows.Forms.DataGridView csv_Before;
        private System.Windows.Forms.Label label_Before;
        private System.Windows.Forms.Label label_After;
        private System.Windows.Forms.TabControl tab_After;
        private System.Windows.Forms.TabPage after_txt;
        private System.Windows.Forms.TabPage after_csv;
        private System.Windows.Forms.DataGridView csv_After;
        private System.Windows.Forms.TextBox txt_BeforePath;
        private System.Windows.Forms.TextBox txt_AfterPath;
        private System.Windows.Forms.Button btn_Indent;
        private System.Windows.Forms.Button btn_Help;
        private System.Windows.Forms.ComboBox cmb_Language;
        private System.Windows.Forms.ColorDialog colorDialog1;
        public System.Windows.Forms.RichTextBox rich_After;
        private System.Windows.Forms.ColorDialog colorDialog2;
        private System.Windows.Forms.ColorDialog colorDialog3;
        private System.Windows.Forms.Button btn_Max;
    }
}

