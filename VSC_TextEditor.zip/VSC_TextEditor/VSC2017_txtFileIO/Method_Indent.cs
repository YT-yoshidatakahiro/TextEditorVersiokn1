﻿using System;

public class Method_Indent
{
	public Method_Indent()
	{
	}
    public const string str_finally = "finally";

    public const string str_repeat = "repeat";

    public const string str_until = "until";

    public const string str_type = "type";

    public const string str_class = "class";
    /// <summary>
    /// インデント設定1：左詰め作業
    /// </summary>
    /// <param name="dat1"></param>
    /// <returns></returns>
    public string Method_Left(string dat1, string path1)
    {
        string tmprstr = "";

        string cutword = "";

        if (path1.EndsWith(".txt"))
        {
            tmprstr = dat1;

            //左詰め作業
            for (int i = 0; i < tmprstr.Length; i++)
            {
                cutword += tmprstr.Substring(i, 1);

                if (cutword.EndsWith("\n" + " "))
                {
                    cutword = cutword.Substring(0, cutword.Length - 1);
                }
            }
        }
        return cutword;
    }
    /// <summary>
    /// beginendのインデント設定
    /// </summary>
    /// <returns></returns>
    public string Method_BeginEnd(string dat1)
    {
        string tmprstr = dat1;
        string cutword = "";
        int flagkakko1 = 0;

        int kakkocount = 0;

        for (int i = 0; i < tmprstr.Length; i++)
        {
            cutword += tmprstr.Substring(i, 1);

            if (cutword.EndsWith("begin") || cutword.EndsWith("try") || cutword.EndsWith(str_repeat) || cutword.EndsWith(str_type))
            {
                flagkakko1 = 1;

                kakkocount += 1;
            }
            if (flagkakko1 == 1)
            {
                if (cutword.EndsWith("\n"))
                {
                    cutword += new string(' ', 2 * kakkocount);
                }
            }
            if (cutword.EndsWith(str_finally))
            {
                cutword = cutword.Substring(0, cutword.Length - str_finally.Length - 2) + str_finally;
            }
            if (cutword.EndsWith(str_until))
            {
                cutword = cutword.Substring(0, cutword.Length - str_until.Length - 2) + str_until;
                kakkocount -= 1;
            }
            if (cutword.EndsWith("\n" + new string(' ', 2 * kakkocount) + "end"))
            {
                cutword = cutword.Substring(0, cutword.Length - 5) + "end";

                kakkocount -= 1;
            }
            if (cutword.EndsWith("end."))
            {
                cutword = cutword.Substring(0, cutword.Length - 4) + "\n" + "end.";

                kakkocount -= 1;
            }

            if (kakkocount == 0)
            {
                flagkakko1 = 0;
            }
            if (kakkocount < 0)
            {
                kakkocount = 0;
            }
        }

        tmprstr = cutword;

        cutword = "";

        kakkocount = 0;

        for (int i = 0; i < tmprstr.Length; i++)
        {
            cutword += tmprstr.Substring(i, 1);

            if (cutword.EndsWith(str_class))
            {
                kakkocount += 1;
                flagkakko1 = 1;
            }
            if (flagkakko1 == 1)
            {
                if (cutword.EndsWith("\n"))
                {
                    cutword += new string(' ', 2 * kakkocount);
                }
            }
            if (kakkocount > 0)
            {
                if (cutword.EndsWith("\n" + new string(' ', 2 * kakkocount) + "end"))
                {
                    cutword = cutword.Substring(0, cutword.Length - 5) + "end";

                    flagkakko1 = 0;

                    kakkocount -= 1;
                }
            }
        }
        return cutword;
    }
}
