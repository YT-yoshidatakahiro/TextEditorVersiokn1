﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VSC2017_txtFileIO
{
    public partial class frm_FindReplace : Form
    {
        Control richafter;

        string fulltext;

        public frm_FindReplace()
        {
            InitializeComponent();
        }
        public frm_FindReplace(Control dat1)
        {
            InitializeComponent();

            richafter = dat1;
        }
        /// <summary>
        /// 閉じる
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Visible = false;
        }
        /// <summary>
        /// 検索
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_Find_Click(object sender, EventArgs e)
        {
            string dummystr = "";

            fulltext = richafter.Text;

            dummystr = Method_FindRep(fulltext, txt_Replace.Text, txt_Find.Text);

            dummystr = "";
        }
        /// <summary>
        /// 置換
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_Replace_Click(object sender, EventArgs e)
        {
            fulltext = richafter.Text;

            richafter.Text = Method_FindRep(fulltext, txt_Replace.Text, txt_Find.Text);
        }
        /// <summary>
        /// 検索置換共通処理
        /// </summary>
        private string Method_FindRep(string dat1, string dat2, string dat3)
        {
            string fulltext = dat1;
            string cutword = "";
            string tmpword = "";
            string findword;
            string repword = dat2;
            int findcount = 0;
            int i = 0;
            txt_Count.Text = "";

            findword = dat3;

            if (fulltext.Length > 0 && findword.Length > 0)
            {
                for (i = 0; i < fulltext.Length; i++)
                {
                    cutword = fulltext.Substring(i, 1);

                    tmpword += cutword;

                    if (tmpword.Length >= findword.Length)
                    {
                        if (findword == tmpword.Substring(i + 1 - findword.Length, findword.Length))
                        {
                            tmpword = tmpword.Substring(0, i + 1 - findword.Length) +
                                repword + fulltext.Substring(i + 1);

                            i = -1;

                            fulltext = tmpword;

                            tmpword = "";

                            findcount += 1;
                        }
                    }
                }
                txt_Count.Text=findcount.ToString();
            }
            return tmpword;
        }

    }
}
