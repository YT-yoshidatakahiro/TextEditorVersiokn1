﻿namespace VSC2017_txtFileIO
{
    partial class frm_FindReplace
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Close = new System.Windows.Forms.Button();
            this.label_Replace = new System.Windows.Forms.Label();
            this.labelFind = new System.Windows.Forms.Label();
            this.txt_Replace = new System.Windows.Forms.TextBox();
            this.txt_Find = new System.Windows.Forms.TextBox();
            this.btn_Replace = new System.Windows.Forms.Button();
            this.btn_Find = new System.Windows.Forms.Button();
            this.txt_Count = new System.Windows.Forms.TextBox();
            this.label_count = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_Close
            // 
            this.btn_Close.Font = new System.Drawing.Font("ＭＳ ゴシック", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btn_Close.Location = new System.Drawing.Point(12, 98);
            this.btn_Close.Name = "btn_Close";
            this.btn_Close.Size = new System.Drawing.Size(82, 37);
            this.btn_Close.TabIndex = 0;
            this.btn_Close.Text = "閉じる";
            this.btn_Close.UseVisualStyleBackColor = true;
            this.btn_Close.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // label_Replace
            // 
            this.label_Replace.AutoSize = true;
            this.label_Replace.Font = new System.Drawing.Font("ＭＳ ゴシック", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label_Replace.Location = new System.Drawing.Point(467, 47);
            this.label_Replace.Name = "label_Replace";
            this.label_Replace.Size = new System.Drawing.Size(109, 19);
            this.label_Replace.TabIndex = 22;
            this.label_Replace.Text = "置換文字列";
            // 
            // labelFind
            // 
            this.labelFind.AutoSize = true;
            this.labelFind.Font = new System.Drawing.Font("ＭＳ ゴシック", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.labelFind.Location = new System.Drawing.Point(467, 15);
            this.labelFind.Name = "labelFind";
            this.labelFind.Size = new System.Drawing.Size(109, 19);
            this.labelFind.TabIndex = 23;
            this.labelFind.Text = "検索文字列";
            // 
            // txt_Replace
            // 
            this.txt_Replace.Font = new System.Drawing.Font("ＭＳ ゴシック", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txt_Replace.Location = new System.Drawing.Point(100, 44);
            this.txt_Replace.Name = "txt_Replace";
            this.txt_Replace.Size = new System.Drawing.Size(361, 26);
            this.txt_Replace.TabIndex = 24;
            // 
            // txt_Find
            // 
            this.txt_Find.Font = new System.Drawing.Font("ＭＳ ゴシック", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txt_Find.Location = new System.Drawing.Point(100, 12);
            this.txt_Find.Name = "txt_Find";
            this.txt_Find.Size = new System.Drawing.Size(361, 26);
            this.txt_Find.TabIndex = 21;
            // 
            // btn_Replace
            // 
            this.btn_Replace.Font = new System.Drawing.Font("ＭＳ ゴシック", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btn_Replace.Location = new System.Drawing.Point(12, 55);
            this.btn_Replace.Name = "btn_Replace";
            this.btn_Replace.Size = new System.Drawing.Size(82, 37);
            this.btn_Replace.TabIndex = 26;
            this.btn_Replace.Text = "置換";
            this.btn_Replace.UseVisualStyleBackColor = true;
            this.btn_Replace.Click += new System.EventHandler(this.btn_Replace_Click);
            // 
            // btn_Find
            // 
            this.btn_Find.Font = new System.Drawing.Font("ＭＳ ゴシック", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btn_Find.Location = new System.Drawing.Point(12, 12);
            this.btn_Find.Name = "btn_Find";
            this.btn_Find.Size = new System.Drawing.Size(82, 37);
            this.btn_Find.TabIndex = 25;
            this.btn_Find.Text = "検索";
            this.btn_Find.UseVisualStyleBackColor = true;
            this.btn_Find.Click += new System.EventHandler(this.btn_Find_Click);
            // 
            // txt_Count
            // 
            this.txt_Count.Font = new System.Drawing.Font("ＭＳ ゴシック", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txt_Count.Location = new System.Drawing.Point(100, 76);
            this.txt_Count.Name = "txt_Count";
            this.txt_Count.Size = new System.Drawing.Size(361, 26);
            this.txt_Count.TabIndex = 27;
            // 
            // label_count
            // 
            this.label_count.AutoSize = true;
            this.label_count.Font = new System.Drawing.Font("ＭＳ ゴシック", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label_count.Location = new System.Drawing.Point(467, 73);
            this.label_count.Name = "label_count";
            this.label_count.Size = new System.Drawing.Size(89, 19);
            this.label_count.TabIndex = 22;
            this.label_count.Text = "検索件数";
            // 
            // frm_FindReplace
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(585, 147);
            this.ControlBox = false;
            this.Controls.Add(this.txt_Count);
            this.Controls.Add(this.label_count);
            this.Controls.Add(this.label_Replace);
            this.Controls.Add(this.labelFind);
            this.Controls.Add(this.txt_Replace);
            this.Controls.Add(this.txt_Find);
            this.Controls.Add(this.btn_Replace);
            this.Controls.Add(this.btn_Find);
            this.Controls.Add(this.btn_Close);
            this.Name = "frm_FindReplace";
            this.Text = "検索置換";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btn_Close;
        private System.Windows.Forms.Label label_Replace;
        private System.Windows.Forms.Label labelFind;
        private System.Windows.Forms.TextBox txt_Replace;
        private System.Windows.Forms.TextBox txt_Find;
        private System.Windows.Forms.Button btn_Replace;
        private System.Windows.Forms.Button btn_Find;
        private System.Windows.Forms.TextBox txt_Count;
        private System.Windows.Forms.Label label_count;
    }
}