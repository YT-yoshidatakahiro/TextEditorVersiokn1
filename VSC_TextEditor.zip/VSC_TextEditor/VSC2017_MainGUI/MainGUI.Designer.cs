﻿namespace VSC2017_MainGUI
{
    partial class frm_Main
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージド リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_OpenDentaku = new System.Windows.Forms.Button();
            this.btn_OpenTextEdit = new System.Windows.Forms.Button();
            this.btn_Close = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_OpenDentaku
            // 
            this.btn_OpenDentaku.Font = new System.Drawing.Font("ＭＳ ゴシック", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btn_OpenDentaku.Location = new System.Drawing.Point(12, 12);
            this.btn_OpenDentaku.Name = "btn_OpenDentaku";
            this.btn_OpenDentaku.Size = new System.Drawing.Size(162, 49);
            this.btn_OpenDentaku.TabIndex = 0;
            this.btn_OpenDentaku.Text = "電卓オープン";
            this.btn_OpenDentaku.UseVisualStyleBackColor = true;
            this.btn_OpenDentaku.Click += new System.EventHandler(this.btn_OpenDentaku_Click);
            // 
            // btn_OpenTextEdit
            // 
            this.btn_OpenTextEdit.Font = new System.Drawing.Font("ＭＳ ゴシック", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btn_OpenTextEdit.Location = new System.Drawing.Point(180, 12);
            this.btn_OpenTextEdit.Name = "btn_OpenTextEdit";
            this.btn_OpenTextEdit.Size = new System.Drawing.Size(252, 49);
            this.btn_OpenTextEdit.TabIndex = 0;
            this.btn_OpenTextEdit.Text = "テキスト編集オープン";
            this.btn_OpenTextEdit.UseVisualStyleBackColor = true;
            this.btn_OpenTextEdit.Click += new System.EventHandler(this.btn_OpenTextEdit_Click);
            // 
            // btn_Close
            // 
            this.btn_Close.Font = new System.Drawing.Font("ＭＳ ゴシック", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btn_Close.Location = new System.Drawing.Point(438, 12);
            this.btn_Close.Name = "btn_Close";
            this.btn_Close.Size = new System.Drawing.Size(103, 49);
            this.btn_Close.TabIndex = 0;
            this.btn_Close.Text = "閉じる";
            this.btn_Close.UseVisualStyleBackColor = true;
            this.btn_Close.Click += new System.EventHandler(this.btn_Close_Click);
            // 
            // frm_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(558, 73);
            this.ControlBox = false;
            this.Controls.Add(this.btn_Close);
            this.Controls.Add(this.btn_OpenTextEdit);
            this.Controls.Add(this.btn_OpenDentaku);
            this.Name = "frm_Main";
            this.Text = "メイン画面";
            this.Load += new System.EventHandler(this.frm_Main_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_OpenDentaku;
        private System.Windows.Forms.Button btn_OpenTextEdit;
        private System.Windows.Forms.Button btn_Close;
    }
}

