﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VSC2017_MainGUI
{
    public partial class frm_Main : Form
    {
        VSC_Dentaku.frm_Dentaku oepndnetaku;

        VSC2017_txtFileIO.frm_txtIO opentxtfileio;

        public frm_Main()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 初期表示設定
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frm_Main_Load(object sender, EventArgs e)
        {
            this.StartPosition = FormStartPosition.Manual;

            this.Location = new Point(600, 10);
        }
        /// <summary>
        /// 閉じる
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_Close_Click(object sender, EventArgs e)
        {
            Close();
        }

        /// <summary>
        /// 電卓アプリ開く
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_OpenDentaku_Click(object sender, EventArgs e)
        {
            oepndnetaku = new VSC_Dentaku.frm_Dentaku();

            oepndnetaku.Show();
        }
        /// <summary>
        /// ファイル編集アプリを開く
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_OpenTextEdit_Click(object sender, EventArgs e)
        {
            opentxtfileio = new VSC2017_txtFileIO.frm_txtIO();

            opentxtfileio.Show();
        }
    }
}
